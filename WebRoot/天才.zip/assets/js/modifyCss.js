var flag=0;
function skip(){
	flag=1;
	window.location.href="Admin-main.html";
	

}
// function load(){
// 用于下载文件
// }
// function User(){
// 	var name=document.getElementById("username").value;
// 	var pass=document.getElementById("pass").value;

// 	用于注销用户
// }